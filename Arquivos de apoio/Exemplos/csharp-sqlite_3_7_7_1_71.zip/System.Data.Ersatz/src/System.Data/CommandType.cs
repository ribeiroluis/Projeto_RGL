﻿namespace System.Data
{
    public enum CommandType
    {
        StoredProcedure = 4,
        TableDirect = 512,
        Text = 1
    }
}