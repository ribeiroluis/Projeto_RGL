﻿using System;

namespace System
{
    public class DuplicateNameException :Exception 
    {
        public DuplicateNameException()
        {

        }

        public DuplicateNameException(string ErrorMessage)
        {

        }
    }
}
