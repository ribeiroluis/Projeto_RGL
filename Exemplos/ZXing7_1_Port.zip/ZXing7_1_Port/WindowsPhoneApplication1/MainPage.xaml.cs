﻿// author .net follower (http://dotnetfollower.com)

using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using Microsoft.Phone.Controls;
using System.Windows.Media.Imaging;
using Helpers;

namespace WindowsPhoneApplication1
{
    public partial class MainPage : PhoneApplicationPage
    {
        // Constructor
        public MainPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            resultTexBlock.Text = string.Empty;

            WriteableBitmap wbmp = new WriteableBitmap(barcodeSample.Source as BitmapImage);
            string recognizedOutput = string.Empty;
            if (BarcodeHelper.TryToRecognizeBarcode(wbmp, out recognizedOutput))
            // if (BarcodeHelper.TryToRecognizeQRcode(wbmp, out recognizedOutput))
            // if (BarcodeHelper.TryToRecognizeDataMatrix(wbmp, out recognizedOutput))
                resultTexBlock.Text = recognizedOutput;
            else
                resultTexBlock.Text = "Unrecognizable barcode!";
        }
    }
}